import Navbar from '@/components/Navbar';
import {
  HeroSection,
  ProblemSection,
  WhatIsSection,
  AudienceSection,
  BigProblemSection,
  TurnSection,
} from '@/components/Sections1to7';
import {
  ModulesSection,
  DiffSection,
  ResultsSection,
  ConceptSection,
  AuthoritySection,
  PromiseSection,
  OfferSection,
  FinalCTASection,
  Footer,
} from '@/components/Sections8to13';

export default function Home() {
  return (
    <>
      <Navbar />
      <HeroSection />
      <ProblemSection />
      <WhatIsSection />
      <AudienceSection />
      <BigProblemSection />
      <TurnSection />
      <ModulesSection />
      <DiffSection />
      <ResultsSection />
      <ConceptSection />
      <AuthoritySection />
      <PromiseSection />
      <OfferSection />
      <FinalCTASection />
      <Footer />
    </>
  );
}
