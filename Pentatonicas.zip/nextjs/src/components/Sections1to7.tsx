'use client';

import { FadeUp } from './FadeUp';
import BassFretboard from './BassFretboard';

const LINK = 'https://pay.kiwify.com.br/Yl6OoSO';

export function HeroSection() {
  return (
    <section className="hero" id="inicio">
      <div className="hero-split">
        <div className="hero-content">
          <FadeUp><span className="eyebrow">A Nova Linguagem da Pentatônica</span></FadeUp>
          <FadeUp delay={0.1}><h1>Domine a <span className="accent">pentatônica</span> no contrabaixo e pare de soar como todo mundo</h1></FadeUp>
          <FadeUp delay={0.2}><p className="hero-sub">Um treinamento do zero ao avançado para baixistas que querem sair dos desenhos decorados, ganhar liberdade no braço e transformar a pentatônica em linguagem musical de verdade.</p></FadeUp>
          <FadeUp delay={0.3}>
            <div className="hero-cta-wrap">
              <a href="#oferta" className="btn-cta btn-cta-pulse">▶ Quero dominar a pentatônica</a>
            </div>
            <p className="hero-note">Treinamento criado por Prof. Joab Pereira para baixistas que querem tocar com mais liberdade, fraseado e identidade musical.</p>
          </FadeUp>
        </div>
        <FadeUp delay={0.3}>
          <div className="hero-visual">
            {/* @ts-expect-error Wistia custom element */}
            <wistia-player media-id="iuieek8lrm" aspect="0.5625"></wistia-player>
          </div>
        </FadeUp>
      </div>
    </section>
  );
}

export function ProblemSection() {
  return (
    <section className="sect sect-dark">
      <div className="sect-inner">
        <FadeUp><h2 className="sect-title">A maioria dos baixistas conhece a pentatônica.<br /><span className="accent">Mas poucos sabem usar.</span></h2></FadeUp>
        <FadeUp delay={0.1}><div className="sect-text">
          <p>O problema não é a escala.</p>
          <p>O problema é que a maioria aprende a pentatônica do jeito mais limitado possível: decorando desenhos, repetindo shapes e tocando sempre as mesmas frases.</p>
          <p>Resultado?</p>
          <p>Você até sabe &quot;onde estão as notas&quot;, mas quando chega a hora de criar, improvisar ou construir uma frase musical de verdade, tudo parece travado.</p>
          <p>A mão até anda.</p>
          <p><strong>Mas a música não fala.</strong></p>
        </div></FadeUp>
        <FadeUp delay={0.2}><div className="callout">E é exatamente isso que o treinamento A Nova Linguagem da Pentatônica resolve.</div></FadeUp>
      </div>
    </section>
  );
}

export function WhatIsSection() {
  return (
    <section className="sect">
      <div className="sect-inner">
        <FadeUp><h2 className="sect-title">O que é o treinamento<br /><span className="accent">A Nova Linguagem da Pentatônica</span></h2></FadeUp>
        <FadeUp delay={0.1}><div className="sect-text">
          <p>A Nova Linguagem da Pentatônica é um treinamento completo para contrabaixistas que querem dominar a pentatônica de uma forma moderna, prática e musical.</p>
          <p>Aqui, você não vai aprender apenas &quot;caixinhas&quot;.</p>
          <p>Você vai entender como a pentatônica funciona, como ela se organiza no braço, como conectar regiões, como criar frases e como aplicar tudo isso em grooves, improvisos, solos, música gospel e progressões modernas.</p>
        </div></FadeUp>
        <FadeUp delay={0.2}><div className="callout">A proposta é simples: fazer você parar de tocar padrões soltos e começar a construir linguagem.</div></FadeUp>
        <FadeUp delay={0.25}>
          <div style={{ maxWidth: 360, margin: '40px auto 0', borderRadius: 'var(--r-xl)', overflow: 'hidden', border: '1px solid rgba(217,163,91,0.18)', boxShadow: '0 20px 60px -15px rgba(0,0,0,0.6)' }}>
            {/* @ts-expect-error Wistia custom element */}
            <wistia-player media-id="iti05qn4ly" aspect="0.4621309370988447"></wistia-player>
          </div>
        </FadeUp>
      </div>
    </section>
  );
}

export function AudienceSection() {
  const cards = [
    { icon: '◇', text: 'Iniciantes que querem aprender a pentatônica do jeito certo desde o começo.' },
    { icon: '◈', text: 'Intermediários que já conhecem alguns desenhos, mas ainda se sentem presos no braço.' },
    { icon: '★', text: 'Avançados que querem expandir vocabulário, fraseado e aplicação musical.' },
    { icon: '♪', text: 'Músicos de igreja que querem tocar com mais intenção, fluidez e musicalidade.' },
    { icon: '⚡', text: 'Improvisadores e solistas que querem criar frases modernas com mais liberdade.' },
    { icon: '◎', text: 'Professores de música que querem organizar melhor a forma de ensinar pentatônica.' },
  ];
  return (
    <section className="sect sect-dark">
      <div className="sect-inner">
        <FadeUp><h2 className="sect-title">Esse treinamento é para baixistas que querem <span className="accent">evoluir de verdade</span></h2></FadeUp>
        <div className="audience-grid">
          {cards.map((c, i) => (
            <FadeUp key={i} delay={i * 0.07}>
              <div className="audience-card">
                <div className="audience-icon">{c.icon}</div>
                <p>{c.text}</p>
              </div>
            </FadeUp>
          ))}
        </div>
        <FadeUp delay={0.5}><div className="callout" style={{ marginTop: 48 }}>Mesmo se você já toca há anos, esse treinamento vai te mostrar possibilidades que provavelmente você ainda não explorou.</div></FadeUp>
      </div>
    </section>
  );
}

export function BigProblemSection() {
  return (
    <section className="sect">
      <div className="sect-inner">
        <FadeUp><h2 className="sect-title">Existe uma diferença enorme entre conhecer a pentatônica e <span className="accent">falar música</span> usando a pentatônica</h2></FadeUp>
        <FadeUp delay={0.1}><div className="sect-text">
          <p>A pentatônica é uma das escalas mais usadas da música moderna. Ela aparece no gospel, no blues, no pop, no fusion, no jazz, no rock e em vários outros estilos.</p>
          <p>Mas a maioria dos baixistas fica presa nisso: sobe e desce escala, repete lick pronto, toca sempre no mesmo lugar do braço e não consegue transformar os padrões em frases com sentido musical.</p>
        </div></FadeUp>
        <FadeUp delay={0.15}><div className="callout">É como ter um monte de palavras soltas, mas não conseguir formar uma frase.</div></FadeUp>
        <FadeUp delay={0.2}>
          <div className="comparison-grid">
            <div className="comp-col muted">
              <h3>O jeito comum</h3>
              <ul>
                <li>Decora desenhos prontos</li>
                <li>Repete shapes sem entender</li>
                <li>Toca sempre na mesma região</li>
                <li>Sobe e desce a escala</li>
                <li>Repete licks de outros</li>
              </ul>
            </div>
            <div className="comp-col ds-accent">
              <h3>A nova linguagem</h3>
              <ul>
                <li>Entende a lógica da escala</li>
                <li>Cria caminhos próprios</li>
                <li>Transita pelo braço inteiro</li>
                <li>Constrói frases musicais</li>
                <li>Desenvolve identidade</li>
              </ul>
            </div>
          </div>
        </FadeUp>
        <FadeUp delay={0.25}><div className="sect-text" style={{ marginTop: 32 }}>
          <p>E música é linguagem. <strong>Não é só digitação.</strong></p>
        </div></FadeUp>
      </div>
    </section>
  );
}

export function TurnSection() {
  return (
    <section className="sect sect-dark">
      <div className="sect-inner">
        <FadeUp><h2 className="sect-title">A virada acontece quando você para de decorar shapes e começa a <span className="accent">enxergar linguagem</span></h2></FadeUp>
        <FadeUp delay={0.1}><div className="sect-text">
          <p>O treinamento A Nova Linguagem da Pentatônica foi criado para mudar sua forma de enxergar essa escala.</p>
          <p>Você vai aprender a pensar em distribuição, conexão, intenção melódica, aplicação e fraseado.</p>
          <p>Na prática, você vai começar a enxergar o braço de forma mais ampla.</p>
        </div></FadeUp>
        <FadeUp delay={0.15}>
          <ul className="turn-list">
            <li>Vai sair das &quot;caixinhas&quot;.</li>
            <li>Vai conectar regiões.</li>
            <li>Vai criar frases com começo, meio e fim.</li>
            <li>Vai entender como transformar padrões simples em ideias musicais modernas.</li>
          </ul>
        </FadeUp>
        <FadeUp delay={0.2}><div className="callout" style={{ textAlign: 'center' }}>É aqui que a pentatônica deixa de ser uma escala comum e começa a virar vocabulário.</div></FadeUp>
      </div>
    </section>
  );
}

export function FretboardSection() {
  return (
    <section className="sect" style={{ background: 'var(--bg-surface)' }}>
      <div className="sect-inner">
        <FadeUp>
          <div style={{ textAlign: 'center', marginBottom: 48 }}>
            <span className="eyebrow">Experimente</span>
            <h2 className="sect-title">Explore as Escalas no Braço</h2>
            <p className="sect-text" style={{ margin: '0 auto' }}>Selecione a tonalidade e o tipo de escala. Clique nas notas para ouvir.</p>
          </div>
        </FadeUp>
        <FadeUp delay={0.2}>
          <BassFretboard />
        </FadeUp>
      </div>
    </section>
  );
}
