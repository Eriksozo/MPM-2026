'use client';

import { useRef, useState, useEffect, ReactNode } from 'react';

export function useInView(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const show = () => setVisible(true);
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight && rect.bottom > 0) { show(); return; }
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { show(); obs.unobserve(el); } },
      { threshold, rootMargin: '50px' }
    );
    obs.observe(el);
    const t = setTimeout(show, 2500);
    return () => { obs.disconnect(); clearTimeout(t); };
  }, [threshold]);

  return [ref, visible] as const;
}

export function FadeUp({
  children, delay = 0, className = '', style = {}
}: {
  children: ReactNode; delay?: number; className?: string; style?: React.CSSProperties;
}) {
  const [ref, visible] = useInView(0.1);
  return (
    <div
      ref={ref}
      className={`fade-up${visible ? ' visible' : ''} ${className}`}
      style={{ transitionDelay: `${delay}s`, ...style }}
    >
      {children}
    </div>
  );
}
