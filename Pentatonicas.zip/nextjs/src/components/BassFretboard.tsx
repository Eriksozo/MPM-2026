'use client';

import { useState } from 'react';

const FB_NOTES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const BASS_STRINGS = [
  { name: 'G', open: 7, freq: 98 },
  { name: 'D', open: 2, freq: 73.42 },
  { name: 'A', open: 9, freq: 55 },
  { name: 'E', open: 4, freq: 41.2 },
];
const SCALE_PATTERNS: Record<string, number[]> = {
  minor: [0, 3, 5, 7, 10],
  major: [0, 2, 4, 7, 9],
};
const FRET_DOTS = [3, 5, 7, 9, 12];
const NUM_FRETS = 12;

let _audioCtx: AudioContext | null = null;

function playNote(freq: number) {
  if (!_audioCtx) _audioCtx = new AudioContext();
  const ctx = _audioCtx;
  const now = ctx.currentTime;
  const osc = ctx.createOscillator(); osc.type = 'triangle'; osc.frequency.value = freq * 2;
  const osc2 = ctx.createOscillator(); osc2.type = 'sine'; osc2.frequency.value = freq * 3;
  const g = ctx.createGain(); g.gain.setValueAtTime(0.22, now); g.gain.exponentialRampToValueAtTime(0.001, now + 1);
  const g2 = ctx.createGain(); g2.gain.setValueAtTime(0.06, now); g2.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
  osc.connect(g).connect(ctx.destination); osc2.connect(g2).connect(ctx.destination);
  osc.start(now); osc2.start(now); osc.stop(now + 1); osc2.stop(now + 0.5);
}

export default function BassFretboard() {
  const [selectedKey, setSelectedKey] = useState('A');
  const [selectedScale, setSelectedScale] = useState('minor');
  const [activeNote, setActiveNote] = useState<string | null>(null);

  const rootIdx = FB_NOTES.indexOf(selectedKey);
  const scaleSet = new Set(SCALE_PATTERNS[selectedScale].map(i => (rootIdx + i) % 12));
  const getNoteIdx = (si: number, f: number) => (BASS_STRINGS[si].open + f) % 12;

  const handleClick = (si: number, fret: number) => {
    playNote(BASS_STRINGS[si].freq * Math.pow(2, fret / 12));
    setActiveNote(`${si}-${fret}`);
    setTimeout(() => setActiveNote(null), 500);
  };

  const accentColor = '#D9A35B';
  const nutW = 32, labelW = 28, strGap = 40, padY = 36;
  const fws = Array.from({ length: NUM_FRETS }, (_, i) => 62 - i * 1.8);
  const fxs: { x: number; w: number }[] = [];
  let cx = 0;
  fws.forEach((w) => { fxs.push({ x: labelW + nutW + cx, w }); cx += w; });
  const totalW = labelW + nutW + cx + 8;
  const totalH = strGap * 3 + padY * 2 + 20;
  const strY = (i: number) => padY + 20 + i * strGap;
  const strThick = [1.2, 1.8, 2.4, 3.2];

  return (
    <div>
      <div className="fretboard-controls">
        <div className="fb-control">
          <label>Tonalidade</label>
          <div className="fb-select-row">
            {FB_NOTES.map(k => (
              <button key={k} className={`fb-pill${selectedKey === k ? ' active' : ''}`}
                onClick={() => setSelectedKey(k)}
                style={selectedKey === k ? { background: accentColor, borderColor: accentColor } : {}}
              >{k}</button>
            ))}
          </div>
        </div>
        <div className="fb-control">
          <label>Escala</label>
          <div className="fb-select-row">
            {([['minor', 'Menor'], ['major', 'Maior']] as const).map(([v, l]) => (
              <button key={v} className={`fb-pill${selectedScale === v ? ' active' : ''}`}
                onClick={() => setSelectedScale(v)}
                style={selectedScale === v ? { background: accentColor, borderColor: accentColor } : {}}
              >{l}</button>
            ))}
          </div>
        </div>
      </div>

      <div className="fretboard-container">
        <svg viewBox={`0 0 ${totalW} ${totalH}`} style={{ display: 'block', margin: '0 auto', width: '100%', maxWidth: totalW, height: 'auto' }}>
          <defs>
            <linearGradient id="wood" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#1E1610" />
              <stop offset="100%" stopColor="#15100C" />
            </linearGradient>
          </defs>
          {/* Fret numbers */}
          {fxs.map((f, i) => (
            <text key={i} x={f.x + f.w / 2} y={14} textAnchor="middle" fill="#444" fontSize="10" fontFamily="var(--font-b)">{i + 1}</text>
          ))}
          {/* Neck */}
          <rect x={labelW} y={padY} width={nutW + cx} height={strGap * 3 + 40} rx="6" fill="url(#wood)" stroke="#2A2015" strokeWidth="1.5" />
          <rect x={labelW} y={padY} width={5} height={strGap * 3 + 40} rx="1.5" fill="#E8DCC8" />
          {/* Fret wires */}
          {fxs.map((f, i) => (
            <line key={i} x1={f.x + f.w} y1={padY + 2} x2={f.x + f.w} y2={padY + strGap * 3 + 38} stroke="#8A7A60" strokeWidth="1.5" opacity="0.5" />
          ))}
          {/* Inlay dots */}
          {FRET_DOTS.map(f => {
            if (f > NUM_FRETS) return null;
            const fc = fxs[f - 1];
            const dotCx = fc.x + fc.w / 2;
            return f === 12 ? (
              <g key={f}>
                <circle cx={dotCx} cy={strY(0) + (strY(1) - strY(0)) / 2} r="5" fill="#2E2418" stroke="#3D3020" strokeWidth="0.5" />
                <circle cx={dotCx} cy={strY(2) + (strY(3) - strY(2)) / 2} r="5" fill="#2E2418" stroke="#3D3020" strokeWidth="0.5" />
              </g>
            ) : (
              <circle key={f} cx={dotCx} cy={(strY(1) + strY(2)) / 2} r="5" fill="#2E2418" stroke="#3D3020" strokeWidth="0.5" />
            );
          })}
          {/* Strings */}
          {BASS_STRINGS.map((s, si) => (
            <g key={si}>
              <line x1={labelW} y1={strY(si)} x2={labelW + nutW + cx} y2={strY(si)}
                stroke={si < 2 ? '#B0A890' : '#8A8070'} strokeWidth={strThick[si]} opacity="0.6" />
              <text x={labelW - 6} y={strY(si) + 4} textAnchor="end" fill="#555" fontSize="11" fontWeight="600" fontFamily="var(--font-b)">{s.name}</text>
            </g>
          ))}
          {/* Scale notes */}
          {BASS_STRINGS.map((_, si) =>
            Array.from({ length: NUM_FRETS + 1 }, (__, fr) => {
              const ni = getNoteIdx(si, fr);
              if (!scaleSet.has(ni)) return null;
              const isR = ni === rootIdx;
              const ncx = fr === 0 ? labelW + nutW / 2 : fxs[fr - 1].x + fxs[fr - 1].w / 2;
              const ncy = strY(si);
              const r = isR ? 15 : 12;
              const k = `${si}-${fr}`;
              const isActive = activeNote === k;
              return (
                <g key={k} onClick={() => handleClick(si, fr)} style={{ cursor: 'pointer' }}>
                  {isActive && (
                    <circle cx={ncx} cy={ncy} r={r + 8} fill="none" stroke={accentColor} strokeWidth="2" opacity="0.4">
                      <animate attributeName="r" from={r + 4} to={r + 16} dur="0.5s" />
                      <animate attributeName="opacity" from="0.6" to="0" dur="0.5s" />
                    </circle>
                  )}
                  <circle cx={ncx} cy={ncy} r={r} fill={isR ? accentColor : `${accentColor}22`} stroke={accentColor} strokeWidth={isR ? 0 : 1.5} />
                  <text x={ncx} y={ncy + 4} textAnchor="middle" fill={isR ? '#0A0A0A' : accentColor}
                    fontSize="10" fontWeight="700" fontFamily="var(--font-b)" style={{ pointerEvents: 'none' }}>
                    {FB_NOTES[ni]}
                  </text>
                </g>
              );
            })
          )}
        </svg>
      </div>
      <p style={{ textAlign: 'center', marginTop: 16, fontSize: 12, color: '#555', fontStyle: 'italic' }}>
        Clique nas notas para ouvir · Pentatônica {selectedScale === 'minor' ? 'Menor' : 'Maior'} de {selectedKey}
      </p>
    </div>
  );
}
