'use client';

import { useState } from 'react';
import { FadeUp } from './FadeUp';

const LINK = 'https://pay.kiwify.com.br/Yl6OoSO';

const MODULES = [
  { num: '01', title: 'Fundamentos da Pentatônica', intro: 'Antes de correr, você precisa entender o mapa. Nesta parte, você aprende a base da escala pentatônica para tocar com clareza e consciência.',
    items: ['Estrutura da escala pentatônica','Formação intervalar','Campo harmônico relacionado','Sonoridade da pentatônica na prática','Visualização da pentatônica em qualquer tonalidade','Como entender a escala sem depender apenas de desenhos prontos'],
    hl: 'Aqui você constrói o alicerce. Sem isso, o resto vira decoreba gourmetizada.' },
  { num: '02', title: 'Distribuições Inteligentes', intro: 'Esse é um dos pontos mais fortes do método. Você vai aprender distribuições que mudam completamente a forma de visualizar a pentatônica no braço.',
    items: ['2x3','3x2','Horizontais','Verticais','Cadenciais','Quartais','Conexões entre shapes','Organização estratégica no braço'],
    hl: 'Essas distribuições ajudam você a sair do óbvio e começar a criar caminhos mais musicais, modernos e inteligentes.' },
  { num: '03', title: 'Desenvolvimento Horizontal no Braço', intro: 'Um dos maiores bloqueios dos baixistas é tocar preso em regiões pequenas. A famosa "caixinha". Nesta parte, você vai aprender a desenvolver fluidez horizontal no braço.',
    items: ['Conexão entre regiões','Expansão de frases','Mobilidade no instrumento','Liberdade para transitar pelo braço','Como não ficar refém de um único shape','Como criar frases que caminham com naturalidade'],
    hl: 'Você começa a tocar pensando no braço inteiro, não em blocos isolados.' },
  { num: '04', title: 'Criação de Frases', intro: 'Saber a escala é uma coisa. Criar frases boas é outra. Nesta etapa, você vai aprender como transformar a pentatônica em fraseado musical.',
    items: ['Frases modernas','Frases melódicas','Frases rápidas','Frases gospel','Construção de identidade musical','Desenvolvimento de linguagem própria','Como organizar ideias para soar mais musical'],
    hl: 'O objetivo não é fazer você copiar frases para sempre. É fazer você entender como as frases nascem.' },
  { num: '05', title: 'Aplicações Musicais', intro: 'Pentatônica sem aplicação é teoria bonita e inútil. Aqui você aprende onde, quando e como usar a pentatônica em situações reais.',
    items: ['Onde usar a pentatônica','Como aplicar em diferentes contextos','Aplicação em grooves','Aplicação no improviso','Aplicação em solos','Uso em música gospel','Uso em progressões modernas','Como pensar musicalmente na prática'],
    hl: 'Essa é a parte onde o estudo vira música. Onde o conceito sai da aula e entra no som.' },
];

export function ModulesSection() {
  const [openIdx, setIdx] = useState<number | null>(0);
  return (
    <section className="sect" id="modulos">
      <div className="sect-inner">
        <FadeUp><h2 className="sect-title">O que você vai aprender <span className="accent">dentro do treinamento</span></h2></FadeUp>
        <div className="modules-list">
          {MODULES.map((m, i) => (
            <FadeUp key={i} delay={i * 0.06}>
              <div className={`module-card${openIdx === i ? ' open' : ''}`}>
                <button className="module-header" onClick={() => setIdx(openIdx === i ? null : i)}>
                  <span className="module-num">{m.num}</span>
                  <div className="module-header-text">
                    <h3>{m.title}</h3>
                    <p>{m.intro.slice(0, 80)}…</p>
                  </div>
                  <span className="module-arrow">▾</span>
                </button>
                <div className="module-body">
                  <div className="module-body-inner">
                    <p style={{ fontSize: 14, color: 'var(--text-mid)', lineHeight: 1.7, marginBottom: 16 }}>{m.intro}</p>
                    <ul className="module-items">
                      {m.items.map((it, j) => <li key={j}>{it}</li>)}
                    </ul>
                    <div className="module-highlight">{m.hl}</div>
                  </div>
                </div>
              </div>
            </FadeUp>
          ))}
        </div>
      </div>
    </section>
  );
}

export function DiffSection() {
  const items = ['Estrutura','Organização','Distribuição','Conexão','Aplicação real','Desenvolvimento criativo','Visão moderna da pentatônica','Construção de linguagem musical'];
  return (
    <section className="sect sect-dark">
      <div className="sect-inner">
        <FadeUp><h2 className="sect-title">O diferencial: você não aprende só desenhos.<br /><span className="accent">Você aprende linguagem.</span></h2></FadeUp>
        <FadeUp delay={0.1}><div className="sect-text"><p>Enquanto muitos treinamentos ensinam apenas desenhos para você decorar, aqui você aprende a lógica por trás da pentatônica.</p></div></FadeUp>
        <FadeUp delay={0.15}><div className="diff-grid">{items.map((it, i) => <div key={i} className="diff-item">{it}</div>)}</div></FadeUp>
        <FadeUp delay={0.2}><div className="callout" style={{ textAlign: 'center' }}>A ideia não é fazer você tocar mais notas. É fazer você tocar melhor. Com intenção. Com fluidez. Com identidade.</div></FadeUp>
      </div>
    </section>
  );
}

export function ResultsSection() {
  const items = ['Enxergar a pentatônica no braço inteiro','Criar frases com mais liberdade','Improvisar com mais segurança','Tocar sem ficar preso em caixinhas','Desenvolver uma linguagem mais moderna','Aplicar pentatônicas em grooves, solos e improvisos','Entender padrões usados por grandes músicos','Construir frases com mais musicalidade','Usar a pentatônica de forma profissional'];
  return (
    <section className="sect">
      <div className="sect-inner">
        <FadeUp><h2 className="sect-title">O que muda na sua forma de tocar <span className="accent">depois do treinamento</span></h2></FadeUp>
        <FadeUp delay={0.1}><ul className="checklist">{items.map((it, i) => <li key={i}><span className="check-icon">✓</span>{it}</li>)}</ul></FadeUp>
        <FadeUp delay={0.2}><div className="callout" style={{ textAlign: 'center' }}>Você deixa de tocar desenhos. E começa a falar música.</div></FadeUp>
      </div>
    </section>
  );
}

export function ConceptSection() {
  return (
    <section className="sect sect-dark">
      <div className="sect-inner">
        <FadeUp><h2 className="sect-title">A pentatônica deixa de ser escala básica e vira <span className="accent">ferramenta de expressão musical</span></h2></FadeUp>
        <FadeUp delay={0.1}><div className="sect-text" style={{ fontSize: 17, lineHeight: 2, textAlign: 'center', margin: '0 auto' }}>
          <p>Esse treinamento não é sobre decorar escala. É sobre mudar sua visão.</p>
          <p>Porque quando você entende a pentatônica como linguagem, tudo muda.</p>
          <p>Você para de pensar apenas em nota. Começa a pensar em frase.</p>
          <p>Para de tocar no automático. Começa a tocar com intenção.</p>
          <p>Para de repetir sempre a mesma ideia. Começa a criar caminhos novos.</p>
        </div></FadeUp>
        <FadeUp delay={0.2}><div className="callout" style={{ textAlign: 'center' }}>A pentatônica deixa de ser uma escala básica e vira uma ferramenta poderosa de expressão musical.</div></FadeUp>
      </div>
    </section>
  );
}

export function AuthoritySection() {
  return (
    <section className="sect">
      <div className="sect-inner">
        <FadeUp><h2 className="sect-title" style={{ textAlign: 'center' }}>Método criado por <span className="accent">Prof. Joab Pereira</span></h2></FadeUp>
        <FadeUp delay={0.1}>
          <div className="authority-card">
            <div className="authority-avatar">JP</div>
            <div className="authority-info">
              <h3>Prof. Joab Pereira</h3>
              <p>O método foi criado a partir de anos de estudo, prática e aplicação real no contrabaixo. Uma abordagem moderna, prática e musical, desenvolvida com foco em linguagem, improviso, groove, fraseado e aplicação dentro da música real.</p>
              <p style={{ marginTop: 12 }}>Não é teoria jogada. Não é conteúdo solto. É um caminho organizado para você entender, aplicar e dominar a pentatônica com clareza.</p>
            </div>
          </div>
        </FadeUp>
      </div>
    </section>
  );
}

export function PromiseSection() {
  return (
    <section className="sect sect-dark">
      <div className="sect-inner" style={{ textAlign: 'center', maxWidth: 720, margin: '0 auto' }}>
        <FadeUp><h2 className="sect-title">Se você quer parar de tocar pentatônica de forma mecânica, <span className="accent">esse treinamento foi feito para você</span></h2></FadeUp>
        <FadeUp delay={0.1}><div className="sect-text" style={{ margin: '0 auto' }}>
          <p>A Nova Linguagem da Pentatônica vai te mostrar como transformar uma das escalas mais conhecidas da música em uma ferramenta avançada de criação no contrabaixo.</p>
          <p>Você vai aprender a usar a pentatônica com liberdade, musicalidade e identidade.</p>
        </div></FadeUp>
        <FadeUp delay={0.15}><div className="callout" style={{ textAlign: 'center' }}>Do zero ao avançado. Da caixinha à linguagem. Da repetição à criação.</div></FadeUp>
      </div>
    </section>
  );
}

export function OfferSection() {
  const benefits = [
    { title: 'Treinamento completo A Nova Linguagem da Pentatônica', desc: 'Uma abordagem prática para dominar a pentatônica do zero ao avançado no contrabaixo.' },
    { title: 'Fundamentos da pentatônica', desc: 'Para entender a estrutura da escala, a formação intervalar, a sonoridade e a aplicação em diferentes tonalidades.' },
    { title: 'Distribuições inteligentes', desc: 'Incluindo 2x3, 3x2, horizontais, verticais, cadenciais, quartais e conexões entre shapes.' },
    { title: 'Desenvolvimento horizontal no braço', desc: 'Para parar de tocar preso em caixinhas e começar a enxergar o braço com mais liberdade.' },
    { title: 'Criação de frases', desc: 'Para construir frases modernas, melódicas, rápidas, gospel e com identidade musical.' },
    { title: 'Aplicações musicais reais', desc: 'Para usar a pentatônica em grooves, improvisos, solos, música gospel e progressões modernas.' },
  ];
  return (
    <section className="sect offer-section" id="oferta">
      <div className="sect-inner">
        <FadeUp><h2 className="sect-title" style={{ textAlign: 'center' }}>Domine a pentatônica no contrabaixo por apenas <span className="accent-warm">R$37,90</span></h2></FadeUp>
        <FadeUp delay={0.1}><div className="sect-text" style={{ margin: '0 auto', textAlign: 'center', maxWidth: 640 }}>
          <p>Você pode continuar tentando juntar vídeos soltos, decorar shapes aleatórios e torcer para uma hora a pentatônica &quot;clicar&quot; na sua cabeça.</p>
          <p>Ou pode seguir um caminho organizado, direto e musical para entender de verdade como usar essa escala no contrabaixo.</p>
        </div></FadeUp>

        <FadeUp delay={0.15}>
          <div className="offer-price-card">
            <span className="eyebrow" style={{ textAlign: 'center', display: 'block', marginBottom: 16 }}>Acesso Completo</span>
            <div className="offer-price">R$37<span className="offer-cents">,90</span></div>
            <p style={{ color: 'var(--text-mid)', fontSize: '0.9rem', marginTop: 8, marginBottom: 28, textAlign: 'center' }}>Acesso ao treinamento completo A Nova Linguagem da Pentatônica.</p>
            <a href={LINK} className="btn-cta btn-cta-pulse" style={{ width: '100%', justifyContent: 'center' }}>▶ Quero acessar o treinamento por R$37,90</a>
          </div>
        </FadeUp>

        <FadeUp delay={0.2}>
          <div style={{ marginTop: 56 }}>
            <h3 className="sect-title" style={{ fontSize: 'clamp(1.2rem,3vw,1.6rem)', textAlign: 'center', marginBottom: 32 }}>O que você recebe ao entrar</h3>
            <div className="offer-benefits-grid">
              {benefits.map((b, i) => (
                <div key={i} className="offer-benefit-card">
                  <span className="check-icon" style={{ marginBottom: 0 }}>✓</span>
                  <div>
                    <strong style={{ color: 'var(--text-high)', fontSize: '0.9rem', display: 'block', marginBottom: 4 }}>{b.title}</strong>
                    <span style={{ fontSize: '0.8rem', color: 'var(--text-mid)', lineHeight: 1.5 }}>{b.desc}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </FadeUp>

        <FadeUp delay={0.25}>
          <div className="offer-value-block">
            <p>Isso é menos do que uma aula particular.</p>
            <p>Menos do que um jogo de cordas simples.</p>
            <p>Menos do que uma saída qualquer no fim de semana.</p>
            <p style={{ marginTop: 16, color: 'var(--text-high)', fontWeight: 700 }}>Mas pode mudar completamente a forma como você entende e aplica a pentatônica no contrabaixo.</p>
          </div>
        </FadeUp>

        <FadeUp delay={0.1}>
          <div style={{ marginTop: 56, textAlign: 'center' }}>
            <h3 className="sect-title" style={{ fontSize: 'clamp(1.2rem,3vw,1.6rem)', textAlign: 'center' }}>Por que o valor é <span className="accent">simbólico?</span></h3>
            <div className="sect-text" style={{ textAlign: 'center', margin: '0 auto' }}>
              <p>Porque a proposta é simples: fazer esse conhecimento chegar a mais baixistas.</p>
              <p>Por R$37,90, você não está comprando apenas aulas sobre uma escala.</p>
              <p><strong>Você está comprando um novo jeito de pensar o contrabaixo.</strong></p>
              <p>Um jeito mais livre. Mais musical. Mais inteligente. Mais profissional.</p>
            </div>
            <div className="callout" style={{ marginTop: 28, textAlign: 'center' }}>Quem aprende pentatônica só por desenho fica limitado.<br />Quem aprende pentatônica como linguagem começa a tocar diferente.</div>
          </div>
        </FadeUp>

        <FadeUp delay={0.1}>
          <div className="offer-impact">
            <p>Se você já sentiu que toca sempre as mesmas frases…</p>
            <p>Se você trava na hora de improvisar…</p>
            <p>Se você até conhece a pentatônica, mas não sabe como transformar isso em música…</p>
            <p className="accent" style={{ fontWeight: 700, marginTop: 16, fontSize: '1.1rem' }}>Esse treinamento é para você.</p>
          </div>
        </FadeUp>

        <FadeUp delay={0.15}>
          <div style={{ textAlign: 'center', marginTop: 48 }}>
            <a href={LINK} className="btn-cta btn-cta-pulse" style={{ fontSize: '1.1rem', padding: '18px 48px' }}>▶ Quero acessar o treinamento por R$37,90</a>
            <p style={{ marginTop: 14, fontSize: '0.75rem', color: 'var(--text-low)', maxWidth: 480, margin: '14px auto 0', letterSpacing: '0.04em' }}>Garanta seu acesso e comece hoje a sair das caixinhas para construir linguagem musical no contrabaixo.</p>
          </div>
        </FadeUp>
      </div>
    </section>
  );
}

export function FinalCTASection() {
  return (
    <section className="final-cta" id="cta">
      <FadeUp>
        <h2 className="sect-title" style={{ textAlign: 'center', maxWidth: 700, margin: '0 auto 16px' }}>Entre agora para o treinamento <span className="accent">A Nova Linguagem da Pentatônica</span></h2>
        <p className="sect-text" style={{ textAlign: 'center', margin: '0 auto 40px', maxWidth: 520 }}>Comece a dominar a pentatônica no contrabaixo do zero ao avançado. Pare de tocar preso em desenhos. Comece a construir linguagem.</p>
        <div style={{ textAlign: 'center' }}>
          <a href="#oferta" className="btn-cta btn-cta-pulse" style={{ fontSize: '1.1rem', padding: '18px 48px' }}>▶ Quero entrar no treinamento</a>
          <p style={{ marginTop: 16, fontSize: '0.75rem', color: 'var(--text-low)', maxWidth: 420, margin: '16px auto 0', letterSpacing: '0.04em' }}>Treinamento completo com abordagem moderna, prática e musical para contrabaixistas.</p>
        </div>
      </FadeUp>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="footer">
      <div className="footer-inner">
        <div className="footer-logo">joab pereira</div>
        <p>© 2026 A Nova Linguagem da Pentatônica · Prof. Joab Pereira</p>
      </div>
    </footer>
  );
}
