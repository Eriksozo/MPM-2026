'use client';

import { useState, useEffect } from 'react';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', h, { passive: true });
    return () => window.removeEventListener('scroll', h);
  }, []);

  return (
    <nav className="nav" style={scrolled ? { background: 'rgba(15,12,9,0.95)' } : {}}>
      <div className="nav-inner">
        <div className="nav-logo">joab pereira</div>
        <div className="nav-links">
          <a href="#modulos">Método</a>
          <a href="#oferta" className="nav-cta">Começar</a>
        </div>
      </div>
    </nav>
  );
}
