# MPM 2026 — A Nova Linguagem da Pentatônica

Landing page do treinamento "A Nova Linguagem da Pentatônica" por Prof. Joab Pereira.

## Tech Stack
- Next.js 14 (App Router, Static Export)
- React 18
- TypeScript
- CSS puro com Custom Properties
- Deploy: Cloudflare Pages

## Setup local
```bash
npm install
npm run dev
```

## Deploy no Cloudflare Pages
1. Conecte o repositório no Cloudflare Pages
2. Build command: `npx @cloudflare/next-on-pages` ou `npm run build`
3. Output directory: `out`
4. Deploy automático a cada push na main
